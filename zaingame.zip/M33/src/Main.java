import java.io.IOException;
import java.util.List;

import game.engine.Battle;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.ComboBox;
public class Main extends Application implements EventHandler<ActionEvent> {
   private Stage mainStage;
    private AnchorPane hs,en;
    private AnchorPane ps;
    private Scene startscene, easygame,hardgame,endScene;
    private Button Start, Purchase, Pass,startmenu;
    private Label Title, Score, Turn, Phase, Resources,l1,l2,l3,l4,l5,we,laneno,end,en2,ins;
    private RadioButton Easy, Hard,W1,W2,W3,W4;
    private VBox Lane1, Lane2, Lane3,Lane4,Lane5,Wall1whole,Wall2whole,Wall3whole,Wall4whole,Wall5whole;
    private HBox Wall1, Wall2, Wall3,Wall4,Wall5;
    
    private Battle battle;
    private ComboBox<String> laneComboBox;
    private Pane s1,s2,s3,s4,s5;
    //private StackPane ls1,ls2,ls3,ls4,ls5;
    private StackPane back;
    private Pane titanStackPane;
    private Lane ll1,ll2,ll3;

    private Button ai;
    
    
    private void updateUI() {
        // Update game information
        Score.setText("Score: " + battle.getScore());
        Turn.setText("Turn: " + battle.getNumberOfTurns());
        Phase.setText("Phase: " + battle.getBattlePhase());
        Resources.setText("Resources: " + battle.getResourcesGathered());

       
        updateLaneUI();

        // Clear the stack panes before updating
        s1.getChildren().clear();
        s2.getChildren().clear();
        s3.getChildren().clear();

       
        for (int i = 0; i < battle.getLanes().size(); i++) {
            Lane lane = battle.getOriginalLanes().get(i);
            Pane laneStackPane = null;

            switch (i) {
                case 0:
                    laneStackPane = s1;
                    break;
                case 1:
                    laneStackPane = s2;
                    break;
                case 2:
                    laneStackPane = s3;
                    break;
                
            }

            if (laneStackPane != null) {
            	laneStackPane.getChildren().clear();
            	for (Titan titan : lane.getTitans()) {
            	    Pane titanStackPane = new Pane();

            	    // Load the image of the titan based on its type
            	    String imagePath = null;
            	    if (titan instanceof PureTitan) {
            	        imagePath = "images11.png";
            	    } else if (titan instanceof AbnormalTitan) {
            	        imagePath = "image21.png";
            	    } else if (titan instanceof ArmoredTitan) {
            	        imagePath = "image31.png";
            	    } else if (titan instanceof ColossalTitan) {
            	        imagePath = "col1.png";
            	    }

            	   
            	    ImageView titanImageView = new ImageView(imagePath);
            	    titanImageView.setFitWidth(30);
            	    titanImageView.setFitHeight(30);
//            	    Label view= new Label();
//            	    view.setGraphic(titanImageView);
//            	    view.setText("titan.getCurrentHealth()");
            	     
            	    titanStackPane.getChildren().add(titanImageView);
            	    laneStackPane.getChildren().add(titanStackPane);
//            	    laneStackPane.getChildren().add(view);
        	        titanStackPane.setLayoutX((Math.random() * laneStackPane.getWidth())); 
        	        titanStackPane.setLayoutY(laneStackPane.getHeight()*((titan.getDistance()+0.0)/battle.getTitanSpawnDistance())); // Place titan at the bottom of the lane
        	        Text text = new Text(""+titan.getCurrentHealth());
        	        titanStackPane.getChildren().add(text);
            	    
            	    
            	}
            	
            }
        
    
        
        }if(battle.isGameOver()){
        	en=new AnchorPane();
        	endScene = new Scene(en,300,300);
        	en.setStyle("-fx-background-color: black;");
        	end = new Label("Game is Over");
        	end.setFont(Font.font("Times New Roman",FontWeight.BOLD,24));
        	end.setTextFill(Color.RED);
        	end.setStyle("-fx-font-style: italic;");
        	end.setLayoutX(23);
        	end.setLayoutY(29);
        	end.setPrefWidth(162);
        	end.setPrefHeight(40);
        	en.getChildren().add(end);
        	en2 = new Label();
        	en2.setText("Score:" +  battle.getScore()+"");
        	en2.setLayoutX(70);
        	en2.setLayoutY(142);
        	en2.setPrefWidth(117);
        	en2.setPrefHeight(40);
        	en2.setTextFill(Color.RED);
        	en.getChildren().add(en2);
        	startmenu = new Button("Click here for Start Menu");
        	startmenu.setLayoutX(48);
        	startmenu.setLayoutY(79);
        	startmenu.setPrefWidth(218);
        	startmenu.setPrefHeight(26);
        	en.getChildren().add(startmenu);
        	mainStage.setScene(endScene);
        	mainStage.show();
        	startmenu.setOnAction(this);
        	
        	
        	
        	
        }
        mainStage.setOnCloseRequest(event->{

        	
        	
        });

}
    private void updateLaneUI() {
        List<Lane> originalLanes = battle.getOriginalLanes();

        // Check if originalLanes is null
        if (originalLanes == null) {
            // Handle case where originalLanes is null
            // Clear the lane panes and labels
            l1.setText("Lane not available");
            l2.setText("Lane not available");
            l3.setText("Lane not available");
            // Clear the lane pane
            Lane1.getChildren().clear();
            Lane2.getChildren().clear();
            Lane3.getChildren().clear();
            return;
        }

        for (int i = 0; i < originalLanes.size(); i++) {
            Lane lane = originalLanes.get(i);
            Label laneLabel = null;
            switch (i) {
                case 0:
                    laneLabel = l1;
                    break;
                case 1:
                    laneLabel = l2;
                    break;
                case 2:
                    laneLabel = l3;
                    break;
                // Add more cases for additional lanes if needed
            }


            if (laneLabel != null) {
                if (lane.isLaneLost()) {
                    laneLabel.setText("Lane " + (i + 1) + " is lost");
                    // Clear the corresponding lane pane
                    switch (i) {
                        case 0:
                            s1.getChildren().clear();
                            break;
                        case 1:
                            s2.getChildren().clear();
                            break;
                        case 2:
                            s3.getChildren().clear();
                            break;
                        // Add more cases for additional lanes if needed
                    }
                } else {
                    laneLabel.setText("danger:" + lane.getDangerLevel() + " Health: " + (lane.getLaneWall() != null ? lane.getLaneWall().getCurrentHealth() : "N/A"));
                }
            }
        }mainStage.setOnCloseRequest(event->{

        	
        	
        });

    }

    
    private void updateUIH() {
        // Update game information
        Score.setText("Score: " + battle.getScore());
        Turn.setText("Turn: " + battle.getNumberOfTurns());
        Phase.setText("Phase: " + battle.getBattlePhase());
        Resources.setText("Resources: " + battle.getResourcesGathered());

        // Update lane UI
        updateLaneUIH();

        // Clear the stack panes before updating
        s1.getChildren().clear();
        s2.getChildren().clear();
        s3.getChildren().clear();
        if(s4!=null)
            s4.getChildren().clear();
        if(s5!=null)
            s5.getChildren().clear();

        // Add titans again to the corresponding lane stack panes
        for (int i = 0; i < battle.getLanes().size(); i++) {
            Lane lane = battle.getOriginalLanes().get(i);
            Pane laneStackPane = null;

            switch (i) {
                case 0:
                    laneStackPane = s1;
                    break;
                case 1:
                    laneStackPane = s2;
                    break;
                case 2:
                    laneStackPane = s3;
                    break;
                case 3:
                    laneStackPane = s4;
                    break;
                case 4:
                    laneStackPane = s5;
                    break;
                // Add more cases for additional lanes if needed
            }

            if (laneStackPane != null) {
                for (Titan titan : lane.getTitans()) {
                    Pane titanStackPane = new Pane();

                    // Load the image of the titan based on its type
                    String imagePath = null;
                    if (titan instanceof PureTitan) {
                        imagePath = "images11.png";
                    } else if (titan instanceof AbnormalTitan) {
                        imagePath = "image21.png";
                    } else if (titan instanceof ArmoredTitan) {
                        imagePath = "image31.png";
                    } else if (titan instanceof ColossalTitan) {
                        imagePath = "col1.png";
                    }

            	    // Create and configure the ImageView for the titan
            	    ImageView titanImageView = new ImageView(imagePath);
            	    titanImageView.setFitWidth(30);
            	    titanImageView.setFitHeight(30);

            	    // Add the titan image to the titan stack pane
            	    titanStackPane.getChildren().add(titanImageView);

            	    // Add the titan stack pane to the lane stack pane
            	    laneStackPane.getChildren().add(titanStackPane);
        	        titanStackPane.setLayoutX((Math.random() * laneStackPane.getWidth())); 
        	        titanStackPane.setLayoutY(laneStackPane.getHeight()*((titan.getDistance()+0.0)/battle.getTitanSpawnDistance())); // Place titan at the bottom of the lane
        	        Text text = new Text(""+titan.getCurrentHealth());
        	        titanStackPane.getChildren().add(text);
                }
            }else {
            	System.out.println("kant null");
            }
        
    

        }if(battle.isGameOver()){
        	en=new AnchorPane();
        	endScene = new Scene(en,300,300);
        	en.setStyle("-fx-background-color: black;");
        	end = new Label("Game is Over");
        	end.setFont(Font.font("Times New Roman",FontWeight.BOLD,24));
        	end.setTextFill(Color.RED);
        	end.setStyle("-fx-font-style: italic;");
        	end.setLayoutX(23);
        	end.setLayoutY(29);
        	end.setPrefWidth(162);
        	end.setPrefHeight(40);
        	en.getChildren().add(end);
        	en2 = new Label();
        	en2.setText("Score:" +  battle.getScore()+"");
        	en2.setTextFill(Color.RED);
        	en2.setLayoutX(70);
        	en2.setLayoutY(142);
        	en2.setPrefWidth(117);
        	en2.setPrefHeight(40);
        	en.getChildren().add(en2);
        	startmenu = new Button("Click here for Start Menu");
        	startmenu.setLayoutX(48);
        	startmenu.setLayoutY(79);
        	startmenu.setPrefWidth(218);
        	startmenu.setPrefHeight(26);
        	en.getChildren().add(startmenu);
        	mainStage.setScene(endScene);
        	mainStage.show();
        	startmenu.setOnAction(this);
        	
        	
        	
        	
        }
        mainStage.setOnCloseRequest(event->{

        	
        	
        });

}
    private void updateLaneUIH() {
        List<Lane> originalLanes = battle.getOriginalLanes();

        // Check if originalLanes is null
        if (originalLanes == null) {
        	l1.setText("Lane not available");
            l2.setText("Lane not available");
            l3.setText("Lane not available");
            l4.setText("Lane not available");
            l5.setText("Lane not available");
            // Clear the lane pane
            Lane1.getChildren().clear();
            Lane2.getChildren().clear();
            Lane3.getChildren().clear();
            Lane4.getChildren().clear();

            Lane5.getChildren().clear();

            return;
        }

        for (int i = 0; i < originalLanes.size(); i++) {
            Lane lane = originalLanes.get(i);
            Label laneLabel = null;
            switch (i) {
                case 0:
                    laneLabel = l1;
                    break;
                case 1:
                    laneLabel = l2;
                    break;
                case 2:
                    laneLabel = l3;
                    break;
                case 3:
                    laneLabel = l4;
                    break;
                case 4:
                    laneLabel = l5;
                    break;
                // Add more cases for additional lanes if needed
            }

            if (laneLabel != null) {
                if (lane.isLaneLost()) {
                    laneLabel.setText("Lane " + (i + 1) + " is lost");
                    // Clear the corresponding lane pane
                    switch (i) {
                        case 0:
                            s1.getChildren().clear();
                            break;
                        case 1:
                            s2.getChildren().clear();
                            break;
                        case 2:
                            s3.getChildren().clear();
                            break;
                        case 3:
                            s4.getChildren().clear();
                            break;
                        case 4:
                            s5.getChildren().clear();
                            break;
                    }
                } else {
                    laneLabel.setText("danger:" + lane.getDangerLevel() + " Health: " + (lane.getLaneWall() != null ? lane.getLaneWall().getCurrentHealth() : "N/A"));
                }
            }else {
            	System.out.println("line 415 lane "+i);
            }
        }
    }
    

    
    
    
    
    
    
    
    
    private void purchaseeasy()  {
//        if()
    	RadioButton selectedWeapon = null;
        int lanec = 0;
        ToggleGroup weap = new ToggleGroup();

     
     W1.setToggleGroup(weap);
     W2.setToggleGroup(weap);
     W3.setToggleGroup(weap);
     W4.setToggleGroup(weap);

     	

        if (W1.isSelected()) {
            selectedWeapon = W1;
           
        } else if (W2.isSelected()) {
            selectedWeapon = W2;
        } else if (W3.isSelected()) {
            selectedWeapon = W3;
        } else if (W4.isSelected()) {
            selectedWeapon = W4;
        }

        if (selectedWeapon != null) {
        	
            String weaponName = selectedWeapon.getText();
            
            // Create the corresponding weapon based on the selected radio button
            switch (weaponName) {
                case "Anti-Titan Shell":
                	 
                	
           
                         String selectedLane = laneComboBox.getValue();
                         HBox weaponBox = null;
                         // Identify the HBox corresponding to the selected lane
                         switch (selectedLane) {
                             case "Lane 1":
                                 weaponBox = (HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                                 lanec=0;
                                 
                                 break;
                             case "Lane 2":
                                 weaponBox = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(1).getWeapons().size()/5)));;
                                 lanec=1;
                                 break;
                             case "Lane 3":
                                 weaponBox = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(2).getWeapons().size()/5)));;;
                                 lanec=2;
                                 break;
                         }
                         try {
         					battle.purchaseWeapon(1, battle.getOriginalLanes().get(lanec));
         				} catch (InsufficientResourcesException e3) {
         					System.out.println("Invalid lane number"+e3.getMessage());
         					e3.printStackTrace();
         					return;
         				} catch (InvalidLaneException e3) {
         					System.out.println("Invalid lane number"+e3.getMessage());
         					e3.printStackTrace();
         					return;
         				}
                         if (weaponBox != null) {
                             ImageView Shell1= new ImageView("shell.jpg");
                             Shell1.setFitWidth(30);
                             Shell1.setFitHeight(30);
                             
                                 Button Shell= new Button();
                                 Shell.setPrefHeight(30);
                                 Shell.setPrefWidth(30);
                        
                                 Shell.setGraphic(Shell1);
                                 // Set any other properties you need for the weapon button
                                 weaponBox.getChildren().add(Shell);
                         }
				
				
				
			
                   break;    
                       
                     
                 
                   
                    
                case "Long RangeSpear" :
                	
                	
                	
                        String selectedLane2 = laneComboBox.getValue();
                        HBox weaponBox2 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane2) {
                        case "Lane 1":
                            weaponBox2 = (HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            lanec=0;
                            break;
                        case "Lane 2":
                            weaponBox2 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(1).getWeapons().size()/5)));;
                            lanec=1;
                            break;
                        case "Lane 3":
                            weaponBox2 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(2).getWeapons().size()/5)));;;
                            lanec=2;
                            break;
                        }
                        try {
        					battle.purchaseWeapon(2, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e2) {
        					System.out.println("Not enough resources"+e2.getMessage());
//        					e2.printStackTrace();
        					return;
        				} catch (InvalidLaneException e2) {
        					System.out.println("Invalid lane number"+e2.getMessage());
        					e2.printStackTrace();
        					return;
        				}
                        if (weaponBox2 != null) {
                        	ImageView Spear1= new ImageView("spear.jpg");
                        	Spear1.setFitWidth(30);
                        	Spear1.setFitHeight(30);
                            
                                Button Spear= new Button();
                                Spear.setPrefHeight(30);
                                Spear.setPrefWidth(30);
                       
                                Spear.setGraphic(Spear1);
                                // Set any other properties you need for the weapon button
                                weaponBox2.getChildren().add(Spear);
                        }
				
                     break;
                      
                    
                
                    
                case "Wall SpreadCannon":
               
                	
                        String selectedLane3 = laneComboBox.getValue();
                        HBox weaponBox3 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane3) {
                        case "Lane 1":
                            weaponBox3 = (HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            lanec=0;
                            break;
                        case "Lane 2":
                            weaponBox3 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(1).getWeapons().size()/5)));;
                            lanec=1;
                            break;
                        case "Lane 3":
                            weaponBox3 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(2).getWeapons().size()/5)));;;
                            lanec=2;
                            break;
                    }
                        try {
        					battle.purchaseWeapon(3, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e1) {
        					System.out.println("Not enough resources"+e1.getMessage());
        					e1.printStackTrace();
        					return;
        				} catch (InvalidLaneException e1) {
        					System.out.println("Invalid lane number"+e1.getMessage());
        					e1.printStackTrace();
        					return;
        				}
                        if (weaponBox3 != null) {
                        	ImageView SpreadCannon1= new ImageView("SpreadCannon.jpg");
                        	SpreadCannon1.setFitWidth(30);
                        	SpreadCannon1.setFitHeight(30);
                            
                                Button SpreadCannon= new Button();
                                SpreadCannon.setPrefHeight(30);
                                SpreadCannon.setPrefWidth(30);
                       
                                SpreadCannon.setGraphic(SpreadCannon1);
                                // Set any other properties you need for the weapon button
                                weaponBox3.getChildren().add(SpreadCannon);
                        }
				
				
				
                      
                      break;
                     
                 
                    
    
                case "Proximity Trap":
                		
                	
                        
                        String selectedLane4 = laneComboBox.getValue();
                        HBox weaponBox4 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane4) {
                        case "Lane 1":
                            weaponBox4 = (HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            lanec=0;
                            break;
                        case "Lane 2":
                            weaponBox4 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(1).getWeapons().size()/5)));;
                            lanec=1;
                            break;
                        case "Lane 3":
                            weaponBox4 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(2).getWeapons().size()/5)));;;
                            
                            lanec=2;
                            break;
                    }
                        try {
        					battle.purchaseWeapon(4, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e) {
        					System.out.println("Not enough resources"+e.getMessage());
        					e.printStackTrace();
        					return;
        				} catch (InvalidLaneException e) {
        					System.out.println("Invalid lane number"+e.getMessage());
        					e.printStackTrace();
        					return;
        				}
                        if (weaponBox4 != null) {
                        ImageView trap= new ImageView("wall.jpg");
                        trap.setFitWidth(30);
                        trap.setFitHeight(30);
                        
                            Button trap1= new Button();
                            trap1.setPrefHeight(30);
                            trap1.setPrefWidth(30);
                   
                            trap1.setGraphic(trap);
                            // Set any other properties you need for the weapon button
                            weaponBox4.getChildren().add(trap1);
                        }
				
				
				
                  break;    
				    
                 
            }
        }
//        W1.setSelected(false);
//        W2.setSelected(false);
//        W3.setSelected(false);
//        W4.setSelected(false);
        
        updateUI();
        
        }
    private void purchasehard()  {
//      if()
    	RadioButton selectedWeapon = null;
        int lanec = 0;
        ToggleGroup weap = new ToggleGroup();

     
     W1.setToggleGroup(weap);
     W2.setToggleGroup(weap);
     W3.setToggleGroup(weap);
     W4.setToggleGroup(weap);

     	

        if (W1.isSelected()) {
            selectedWeapon = W1;
           
        } else if (W2.isSelected()) {
            selectedWeapon = W2;
        } else if (W3.isSelected()) {
            selectedWeapon = W3;
        } else if (W4.isSelected()) {
            selectedWeapon = W4;
        }

        if (selectedWeapon != null) {
        	
            String weaponName = selectedWeapon.getText();
            
            // Create the corresponding weapon based on the selected radio button
            switch (weaponName) {
                case "Anti-Titan Shell":
                	 
                	
           
                         String selectedLane = laneComboBox.getValue();
                         HBox weaponBox = null;
                         // Identify the HBox corresponding to the selected lane
                         switch (selectedLane) {
                         case "Lane 1":
                             lanec=0;
                             weaponBox =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                             break;
                         case "Lane 2":
                             lanec=1;
                             weaponBox = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                             break;
                         case "Lane 3":
                             lanec=2;
                             weaponBox = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                             break;
                         case "Lane 4":
                             lanec=3;
                             weaponBox = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                             break;
                         case "Lane 5":
                             lanec=4;
                             weaponBox = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                             break;
                             
                     }
                         try {
         					battle.purchaseWeapon(1, battle.getOriginalLanes().get(lanec));
         				} catch (InsufficientResourcesException e3) {
         					System.out.println("Invalid lane number"+e3.getMessage());
         					e3.printStackTrace();
         					return;
         				} catch (InvalidLaneException e3) {
         					System.out.println("Invalid lane number"+e3.getMessage());
         					e3.printStackTrace();
         					return;
         				}
                         if (weaponBox != null) {
                             ImageView Shell1= new ImageView("shell.jpg");
                             Shell1.setFitWidth(30);
                             Shell1.setFitHeight(30);
                             
                                 Button Shell= new Button();
                                 Shell.setPrefHeight(30);
                                 Shell.setPrefWidth(30);
                        
                                 Shell.setGraphic(Shell1);
                                 // Set any other properties you need for the weapon button
                                 weaponBox.getChildren().add(Shell);
                         }
				
				
				
			
                   break;    
                       
                     
                 
                   
                    
                case "Long RangeSpear" :
                	
                	
                	
                        String selectedLane2 = laneComboBox.getValue();
                        HBox weaponBox2 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane2) {
                        case "Lane 1":
                            lanec=0;
                            weaponBox2 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case "Lane 2":
                            lanec=1;
                            weaponBox2 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 3":
                            lanec=2;
                            weaponBox2 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 4":
                            lanec=3;
                            weaponBox2 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 5":
                            lanec=4;
                            weaponBox2 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                            
                    }
                        try {
        					battle.purchaseWeapon(2, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e2) {
        					System.out.println("Not enough resources"+e2.getMessage());
        					e2.printStackTrace();
        					return;
        				} catch (InvalidLaneException e2) {
        					System.out.println("Invalid lane number"+e2.getMessage());
        					e2.printStackTrace();
        					return;
        				}
                        if (weaponBox2 != null) {
                        	ImageView Spear1= new ImageView("spear.jpg");
                        	Spear1.setFitWidth(30);
                        	Spear1.setFitHeight(30);
                            
                                Button Spear= new Button();
                                Spear.setPrefHeight(30);
                                Spear.setPrefWidth(30);
                       
                                Spear.setGraphic(Spear1);
                                // Set any other properties you need for the weapon button
                                weaponBox2.getChildren().add(Spear);
                        }
				
                     break;
                      
                    
                
                    
                case "Wall SpreadCannon":
               
                	
                        String selectedLane3 = laneComboBox.getValue();
                        HBox weaponBox3 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane3) {
                        case "Lane 1":
                            lanec=0;
                            weaponBox3 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case "Lane 2":
                            lanec=1;
                            weaponBox3 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 3":
                            lanec=2;
                            weaponBox3 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 4":
                            lanec=3;
                            weaponBox3 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 5":
                            lanec=4;
                            weaponBox3 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                            
                    }
                        try {
        					battle.purchaseWeapon(3, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e1) {
        					System.out.println("Not enough resources"+e1.getMessage());
        					e1.printStackTrace();
        					return;
        				} catch (InvalidLaneException e1) {
        					System.out.println("Invalid lane number"+e1.getMessage());
        					e1.printStackTrace();
        					return;
        				}
                        if (weaponBox3 != null) {
                        	ImageView SpreadCannon1= new ImageView("SpreadCannon.jpg");
                        	SpreadCannon1.setFitWidth(30);
                        	SpreadCannon1.setFitHeight(30);
                            
                                Button SpreadCannon= new Button();
                                SpreadCannon.setPrefHeight(30);
                                SpreadCannon.setPrefWidth(30);
                       
                                SpreadCannon.setGraphic(SpreadCannon1);
                                // Set any other properties you need for the weapon button
                                weaponBox3.getChildren().add(SpreadCannon);
                        }
				
				
				
                      
                      break;
                     
                 
                    
    
                case "Proximity Trap":
                		
                	
                        
                        String selectedLane4 = laneComboBox.getValue();
                        HBox weaponBox4 = null;

                        // Identify the HBox corresponding to the selected lane
                        switch (selectedLane4) {
                        case "Lane 1":
                            lanec=0;
                            weaponBox4 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case "Lane 2":
                            lanec=1;
                            weaponBox4 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 3":
                            lanec=2;
                            weaponBox4 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 4":
                            lanec=3;
                            weaponBox4 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case "Lane 5":
                            lanec=4;
                            weaponBox4 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                            
                    }
                        try {
        					battle.purchaseWeapon(4, battle.getOriginalLanes().get(lanec));
        				} catch (InsufficientResourcesException e) {
        					System.out.println("Not enough resources"+e.getMessage());
        					e.printStackTrace();
        					return;
        				} catch (InvalidLaneException e) {
        					System.out.println("Invalid lane number"+e.getMessage());
        					e.printStackTrace();
        					return;
        				}
                        if (weaponBox4 != null) {
                        ImageView trap= new ImageView("wall.jpg");
                        trap.setFitWidth(30);
                        trap.setFitHeight(30);
                        
                            Button trap1= new Button();
                            trap1.setPrefHeight(30);
                            trap1.setPrefWidth(30);
                   
                            trap1.setGraphic(trap);
                            // Set any other properties you need for the weapon button
                            weaponBox4.getChildren().add(trap1);
                        }
				
				
				
                  break;    
				    
                 
            }
        }
//        W1.setSelected(false);
//        W2.setSelected(false);
//        W3.setSelected(false);
//        W4.setSelected(false);
        
        updateUIH();
        
        }

    private void purchasehard(int weapontype, int laneo)  {
//      if()
        int lanec = laneo;

            // Create the corresponding weapon based on the selected radio button
            switch (weapontype) {
                case 1:



                    String selectedLane = laneComboBox.getValue();
                    HBox weaponBox = null;
                    // Identify the HBox corresponding to the selected lane
                    switch (laneo) {
                        case 0:
                            lanec=0;
                            weaponBox =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case 1:
                            lanec=1;
                            weaponBox = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 2:
                            lanec=2;
                            weaponBox = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 3:
                            lanec=3;
                            weaponBox = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 4:
                            lanec=4;
                            weaponBox = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;

                    }
                    try {
                        battle.purchaseWeapon(1, battle.getOriginalLanes().get(lanec));
                    } catch (InsufficientResourcesException e3) {
                        System.out.println("Invalid lane number"+e3.getMessage());
                        e3.printStackTrace();
                        return;
                    } catch (InvalidLaneException e3) {
                        System.out.println("Invalid lane number"+e3.getMessage());
                        e3.printStackTrace();
                        return;
                    }
                    if (weaponBox != null) {
                        ImageView Shell1= new ImageView("shell.jpg");
                        Shell1.setFitWidth(30);
                        Shell1.setFitHeight(30);

                        Button Shell= new Button();
                        Shell.setPrefHeight(30);
                        Shell.setPrefWidth(30);

                        Shell.setGraphic(Shell1);
                        // Set any other properties you need for the weapon button
                        weaponBox.getChildren().add(Shell);
                    }




                    break;





                case 2 :



                    String selectedLane2 = laneComboBox.getValue();
                    HBox weaponBox2 = null;

                    // Identify the HBox corresponding to the selected lane
                    switch (lanec) {
                        case 0:
                            lanec=0;
                            weaponBox2 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case 1:
                            lanec=1;
                            weaponBox2 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 2:
                            lanec=2;
                            weaponBox2 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 3:
                            lanec=3;
                            weaponBox2 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 4:
                            lanec=4;
                            weaponBox2 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;

                    }
                    try {
                        battle.purchaseWeapon(2, battle.getOriginalLanes().get(lanec));
                    } catch (InsufficientResourcesException e2) {
                        System.out.println("Not enough resources"+e2.getMessage());
                        e2.printStackTrace();
                        return;
                    } catch (InvalidLaneException e2) {
                        System.out.println("Invalid lane number"+e2.getMessage());
                        e2.printStackTrace();
                        return;
                    }
                    if (weaponBox2 != null) {
                        ImageView Spear1= new ImageView("spear.jpg");
                        Spear1.setFitWidth(30);
                        Spear1.setFitHeight(30);

                        Button Spear= new Button();
                        Spear.setPrefHeight(30);
                        Spear.setPrefWidth(30);

                        Spear.setGraphic(Spear1);
                        // Set any other properties you need for the weapon button
                        weaponBox2.getChildren().add(Spear);
                    }

                    break;




                case 3:


                    String selectedLane3 = laneComboBox.getValue();
                    HBox weaponBox3 = null;

                    // Identify the HBox corresponding to the selected lane
                    switch (lanec) {
                        case 0:
                            lanec=0;
                            weaponBox3 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case 1:
                            lanec=1;
                            weaponBox3 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 2:
                            lanec=2;
                            weaponBox3 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 3:
                            lanec=3;
                            weaponBox3 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 4:
                            lanec=4;
                            weaponBox3 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;

                    }
                    try {
                        battle.purchaseWeapon(3, battle.getOriginalLanes().get(lanec));
                    } catch (InsufficientResourcesException e1) {
                        System.out.println("Not enough resources"+e1.getMessage());
                        e1.printStackTrace();
                        return;
                    } catch (InvalidLaneException e1) {
                        System.out.println("Invalid lane number"+e1.getMessage());
                        e1.printStackTrace();
                        return;
                    }
                    if (weaponBox3 != null) {
                        ImageView SpreadCannon1= new ImageView("SpreadCannon.jpg");
                        SpreadCannon1.setFitWidth(30);
                        SpreadCannon1.setFitHeight(30);

                        Button SpreadCannon= new Button();
                        SpreadCannon.setPrefHeight(30);
                        SpreadCannon.setPrefWidth(30);

                        SpreadCannon.setGraphic(SpreadCannon1);
                        // Set any other properties you need for the weapon button
                        weaponBox3.getChildren().add(SpreadCannon);
                    }




                    break;




                case 4:



                    String selectedLane4 = laneComboBox.getValue();
                    HBox weaponBox4 = null;

                    // Identify the HBox corresponding to the selected lane
                    switch (lanec) {
                        case 0:
                            weaponBox4 =(HBox) Wall1whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(0).getWeapons().size()/5)));
                            break;
                        case 1:
                            weaponBox4 = (HBox) Wall2whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 2:
                            weaponBox4 = (HBox) Wall3whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 3:
                            weaponBox4 = (HBox) Wall4whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;
                        case 4:
                            weaponBox4 = (HBox) Wall5whole.getChildren().get(Math.min(3,(battle.getOriginalLanes().get(lanec).getWeapons().size()/5)));
                            break;

                    }
                    try {
                        battle.purchaseWeapon(4, battle.getOriginalLanes().get(lanec));
                    } catch (InsufficientResourcesException e) {
                        System.out.println("Not enough resources"+e.getMessage());
                        e.printStackTrace();
                        return;
                    } catch (InvalidLaneException e) {
                        System.out.println("Invalid lane number"+e.getMessage());
                        e.printStackTrace();
                        return;
                    }
                    if (weaponBox4 != null) {
                        ImageView trap= new ImageView("wall.jpg");
                        trap.setFitWidth(30);
                        trap.setFitHeight(30);

                        Button trap1= new Button();
                        trap1.setPrefHeight(30);
                        trap1.setPrefWidth(30);

                        trap1.setGraphic(trap);
                        // Set any other properties you need for the weapon button
                        weaponBox4.getChildren().add(trap1);
                    }



                    break;


            }

//        W1.setSelected(false);
//        W2.setSelected(false);
//        W3.setSelected(false);
//        W4.setSelected(false);

        updateUIH();

    }
  	
    


    
    public void start(Stage mainStage) throws Exception {
        this.mainStage = mainStage;
        hs = new AnchorPane();
        Image back = new Image("b3.jpg");
        Image BackgroundImage;
		BackgroundImage background = new BackgroundImage(back,null,null, BackgroundPosition.DEFAULT,BackgroundSize.DEFAULT);
        Background backpbj=new Background(background);
         hs.setBackground(backpbj);
        startscene = new Scene(hs, 800, 400);
        ins = new Label("The game has no win condition; players aim to defeat enemies until all starting lanes lose their Wall Parts, resulting in a final score."+"\n"+"Titans move closer to walls each turn based on their speed, with Colossal Titans moving faster."+"\n"+"Both Titans and Weapons perform attack actions: Titans attack walls, while Weapons target Titans based on a predefined table."+"\n"+"Defeated Titans and Wall Parts are removed from the game, with defeated Titans contributing to resources and score."+"\n"+"Defeated Titans and Wall Parts are removed from the game, with defeated Titans contributing to resources and score."+"\n"+"Approaching Titans queue determines which Titans are added to lanes each turn, refilling under specific conditions."+"\n"+"The number of Titans added to lanes and battle phase change based on elapsed turns, with approaching Titans refilling accordingly.");


        ins.setLayoutX(0);
        ins.setLayoutY(99);
        ins.setPrefWidth(800);
        ins.setPrefHeight(200);
        ins.setFont(Font.font("Arial",FontWeight.BOLD,12));
        ins.setTextFill(Color.WHITE);
        hs.getChildren().add(ins);
        
        Title = new Label("Attack on Titans Utopia");
        Title.setFont(Font.font("Arial",FontWeight.BOLD,18));
        Title.setTextFill(Color.WHITE);
        Title.setLayoutX(242);
        Title.setLayoutY(28);
        Title.setPrefWidth(300);
        Title.setPrefHeight(18);
        hs.getChildren().add(Title);

        Label modeinfo = new Label("Easy for 3 lanes and hard for 5 lanes");
        modeinfo.setFont(Font.font("Arial", 12));
        modeinfo.setTextFill(Color.WHITE);
        modeinfo.setLayoutX(14);
        modeinfo.setLayoutY(303);
        modeinfo.setPrefWidth(214);
        modeinfo.setPrefHeight(42);
        hs.getChildren().add(modeinfo);

        Easy = new RadioButton("Easy");
        Easy.setFont(Font.font("Arial", 12));
        Easy.setTextFill(Color.WHITE);
        Easy.setLayoutX(260);
        Easy.setLayoutY(311);
        Easy.setPrefWidth(75);
        Easy.setPrefHeight(25.6);
        hs.getChildren().add(Easy);

        Hard = new RadioButton("Hard");
        Hard.setFont(Font.font("Arial", 12));
        Hard.setTextFill(Color.WHITE);
        Hard.setLayoutX(364);
        Hard.setLayoutY(311);
        Hard.setPrefWidth(75);
        Hard.setPrefHeight(25.6);
        hs.getChildren().add(Hard);
        mainStage.setOnCloseRequest(event->{

        	
        	
        	
        });

        Start = new Button("Start");
        Start.setFont(Font.font("Arial", 12));
        Start.setLayoutX(283);
        Start.setLayoutY(345);
        Start.setPrefWidth(130);
        Start.setPrefHeight(26);
        hs.getChildren().add(Start);
        mainStage.setScene(startscene);
        mainStage.show();
        Easy.setSelected(true);
        ToggleGroup t= new ToggleGroup();
        Easy.setToggleGroup(t);
        Hard.setToggleGroup(t);
        Start.setOnAction(this);
        
    }
   

       
    
    public void handle(ActionEvent event) {
        if (event.getSource() == Start) {
            if (Easy.isSelected()) {
                try {
                    battle = new Battle(1, 0, 100, 3, 250);
                } catch (IOException e) {
                    
                	System.out.println("Error, try again"+e.getMessage());
                	e.printStackTrace();
                    
                }
                ps = new AnchorPane();
                ps.setStyle("-fx-background-color: lightgreen;");
                easygame = new Scene(ps, 1500, 1000);
                Lane1=new VBox();
   			 Lane1.setLayoutX(7);
   			 Lane1.setLayoutY(7);
   			 Lane1.setPrefWidth(260);
   			 Lane1.setPrefHeight(200);
   			 ps.getChildren().add(Lane1);
   			 Lane2=new VBox();
   			 Lane2.setLayoutX(281);
   			 Lane2.setLayoutY(7);
   			 Lane2.setPrefWidth(260);
   			 Lane2.setPrefHeight(200);
   			 ps.getChildren().add(Lane2);
   			 Lane3=new VBox();
   			 Lane3.setLayoutX(556);
   			 Lane3.setLayoutY(7);
   			 Lane3.setPrefWidth(260);
   			 Lane3.setPrefHeight(200);
   			 ps.getChildren().add(Lane3);
   			 we = new Label("Weapon");
   			 we.setLayoutX(23);
   			 we.setLayoutY(864);
   			 we.setPrefWidth(95);
   			 we.setPrefHeight(41);
   			 ps.getChildren().add(we);
   			 
   			 
   			W1 = new RadioButton("Anti-Titan Shell");
   			 W1.setLayoutX(167);
   			 W1.setLayoutY(840);
   			 W1.setPrefWidth(170);
   			 W1.setPrefHeight(25);
   			 ps.getChildren().add(W1);
   			W2 = new RadioButton("Long RangeSpear");
   			 W2.setLayoutX(167);
   			 W2.setLayoutY(870);
   			 W2.setPrefWidth(170);
   			 W2.setPrefHeight(25);
   			 ps.getChildren().add(W2);
   			W3 = new RadioButton("Wall SpreadCannon");
   			 W3.setLayoutX(167);
   			 W3.setLayoutY(896);
   			 W3.setPrefWidth(170);
   			 W3.setPrefHeight(25);
   			 ps.getChildren().add(W3);
   			W4 = new RadioButton("Proximity Trap");
   			 W4.setLayoutX(167);
   			 W4.setLayoutY(923);
   			 W4.setPrefWidth(170);
   			 W4.setPrefHeight(25);
   			 ps.getChildren().add(W4);
   			 s1=new Pane();
   			 s1.setLayoutX(7);
   			 s1.setLayoutY(207);
   			 s1.setPrefWidth(200);
   			 s1.setPrefHeight(500);
   			s1.setStyle("-fx-background-color: white;");
   			 ps.getChildren().add(s1);
   			 
   			 s2=new Pane();
  			 s2.setLayoutX(281);
  			 s2.setLayoutY(207);
  			 s2.setPrefWidth(200);
  			 s2.setPrefHeight(500);
  			s2.setStyle("-fx-background-color: white;");
  			 ps.getChildren().add(s2);
  			 s3=new Pane();
  			 s3.setLayoutX(556);
  			 s3.setLayoutY(207);
  			 s3.setPrefWidth(200);
  			 s3.setPrefHeight(500);
  			s3.setStyle("-fx-background-color: white;");
  			 ps.getChildren().add(s3);
   			 Purchase = new Button("purchase");
   			 Purchase.setLayoutX(381);
   			 Purchase.setLayoutY(854);
   			 Purchase.setPrefWidth(88);
   			 Purchase.setPrefHeight(26);
   			 Purchase.setOnMouseClicked( ae -> {purchaseeasy();});
   			 ps.getChildren().add(Purchase);
   			
   			 
   			 Label l1 = new Label();
   			 l1.setLayoutX(0);
   			 l1.setLayoutY(0);
   			 l1.setPrefWidth(260);
   			 l1.setPrefHeight(27);
   			 l1.setStyle("-fx-background-image: url('wall3.jpg');");
   			 l1.setTextFill(Color.WHITE);
   			 Lane1.getChildren().add(l1);
   			 Label l2 = new Label();
   			 l2.setLayoutX(0);
   			 l2.setLayoutY(0);
   			 l2.setPrefWidth(260);
   			 l2.setPrefHeight(27);
   			l2.setStyle("-fx-background-image: url('wall3.jpg');");
  			 l2.setTextFill(Color.WHITE);
   			 Lane2.getChildren().add(l2);
   			 Label l3 = new Label();
   			 l3.setLayoutX(0);
   			 l3.setLayoutY(0);
   			 l3.setPrefWidth(260);
   			 l3.setPrefHeight(27);
   			l3.setStyle("-fx-background-image: url('wall3.jpg');");
 			 l3.setTextFill(Color.WHITE);
//   			 ImageView img= new ImageView("manga.png");
//   			 img.setScaleZ(100);
//   			 Lane3.getChildren().add(img);
   			 Lane3.getChildren().add(l3);
   			 Wall1whole = new VBox();
   			 for(int i=0;i<4;i++) {
   				 HBox wallll= new HBox(); 
   				wallll.setLayoutX(0);
   				wallll.setLayoutY(0+32*i);
   				wallll.setPrefWidth(200);
   				wallll.setPrefHeight(30);
   				Wall1whole.getChildren().add(wallll);
   			 }
   			 Wall1 = new HBox();
   			 Wall1.setLayoutX(0);
   			 Wall1.setLayoutY(0);
   			 Wall1.setPrefWidth(200);
   			 Wall1.setPrefHeight(150);
   			 Lane1.getChildren().add(Wall1whole);
   			 Wall2whole = new VBox();
   			 for(int i=0;i<4;i++) {
   				 HBox wallll= new HBox(); 
   				wallll.setLayoutX(0);
   				wallll.setLayoutY(0+32*i);
   				wallll.setPrefWidth(200);
   				wallll.setPrefHeight(30);
   				Wall2whole.getChildren().add(wallll);
   			 }
   			 Wall2 = new HBox();
   			 Wall2.setLayoutX(0);
   			 Wall2.setLayoutY(0);
   			 Wall2.setPrefWidth(200);
   			 Wall2.setPrefHeight(150);
   			 Lane2.getChildren().add(Wall2whole);
   			Wall3whole = new VBox();
  			 for(int i=0;i<4;i++) {
  				 HBox wallll= new HBox(); 
  				wallll.setLayoutX(0);
  				wallll.setLayoutY(0+32*i);
  				wallll.setPrefWidth(200);
  				wallll.setPrefHeight(30);
  				Wall3whole.getChildren().add(wallll);
  			 }
   			 Wall3 = new HBox();
   			 Wall3.setLayoutX(0);
   			 Wall3.setLayoutY(0);
   			 Wall3.setPrefWidth(200);
   			 Wall3.setPrefHeight(150);
   			 Lane3.getChildren().add( Wall3whole);
   			
   			 Score = new Label();
   			 Score.setLayoutX(476);
   			 Score.setLayoutY(867);
   			 Score.setPrefWidth(113);
   			 Score.setPrefHeight(18);
   			 ps.getChildren().add( Score);
   			 Turn = new Label();
   			 Turn.setLayoutX(476);
   			 Turn.setLayoutY(896);
   			 Turn.setPrefWidth(113);
   			 Turn.setPrefHeight(18); 
   			 ps.getChildren().add( Turn);
   			 Phase = new Label();
   			 Phase.setLayoutX(476);
   			 Phase.setLayoutY(923);
   			 Phase.setPrefWidth(125);
   			 Phase.setPrefHeight(18);
   			 ps.getChildren().add( Phase);
   			 Resources = new Label();
   			 Resources.setLayoutX(476);
   			 Resources.setLayoutY(951);
   			 Resources.setPrefWidth(113);
   			 Resources.setPrefHeight(18);
   			 ps.getChildren().add( Resources);
   			 Label WeaponInfo = new Label("Weapon details"+"\n"+"Anti-TitanShell: type: PiercingCannon, price: 25, damage: 10"+"\n"+"Long Range Spear: type: Sniper Cannon ,price: 25, damage: 35 "+"\n"+"Wall Spread Cannon: type: Volley Spread Cannon, price: 100, damage: 5 "+"\n"+"Proximity Trap: type: Wall Trap, price: 75, damage: 100"+"\n");
   			 WeaponInfo.setLayoutX(715);
   			 WeaponInfo.setLayoutY(785);
   			 WeaponInfo.setPrefWidth(700);
   			 WeaponInfo.setPrefHeight(188);
   			 ps.getChildren().add(WeaponInfo);
   			 Score.setText("score:"+battle.getScore());
   			Turn.setText("Turn:"+battle.getNumberOfTurns());
   			Phase.setText("Phase"+battle.getBattlePhase());
   			Resources.setText("Resources"+battle.getResourcesGathered());
   			l1.setText("danger:"+battle.getOriginalLanes().get(0).getDangerLevel()+"     Health"+battle.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
        	l2.setText("danger:"+battle.getOriginalLanes().get(1).getDangerLevel()+"    Health"+battle.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
   			l3.setText("danger:"+battle.getOriginalLanes().get(2).getDangerLevel()+"    Health"+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
   			this.l1=l1;
   			this.l2=l2;
   			this.l3=l3;

   			laneno= new Label("Lane number");
   			laneno.setLayoutX(19);
      		 laneno.setLayoutY(950);
      		 laneno.setPrefWidth(111);
      		 laneno.setPrefHeight(27);
      		 ps.getChildren().add(laneno);
   			laneComboBox = new ComboBox<>();
   		 laneComboBox.getItems().addAll("Lane 1", "Lane 2", "Lane 3");
   		 laneComboBox.setLayoutX(151);
   		 laneComboBox.setLayoutY(956);
   		 laneComboBox.setPrefWidth(170);
   		 laneComboBox.setPrefHeight(25);
   		 ps.getChildren().add(laneComboBox);
//   		 ls1= new StackPane();
//   		 ls1.setLayoutX(7);
//	     ls1.setLayoutY(207);
//		 ls1.setPrefWidth(260);
//		 ls1.setPrefHeight(500);
//	     ls2= new StackPane();
//		 ls2.setLayoutX(281);
//		 ls2.setLayoutY(207);
//		 ls2.setPrefWidth(260);
//		 ls2.setPrefHeight(500);
//		 ls3= new StackPane();
//		 ls3.setLayoutX(556);
//		 ls3.setLayoutY(207);
//		 ls3.setPrefWidth(260);
//		 ls3.setPrefHeight(500);
//   			
   			Pass = new Button("Pass Turn");
  			 Pass.setLayoutX(373);
  			 Pass.setLayoutY(863);
  			 Pass.setPrefWidth(88);
  			 Pass.setPrefHeight(26);
  			
  			 
  			Pass.setOnMouseClicked( ae -> { 
        	battle.passTurn();updateUI();});
  			ps.getChildren().add(Pass);
  			ai= new Button("Ai turn");
  			ai.setLayoutX(573);
 			 ai.setLayoutY(863);
 			 ai.setPrefWidth(88);
 			 ai.setPrefHeight(26);
 			 ai.setOnMouseClicked(e->{
                 try {
                     calculateBestMove(3);
                 } catch (IOException ex) {
                     throw new RuntimeException(ex);
                 }
                 updateUI();
 			 });
                ps.getChildren().add(ai);

                mainStage.setMaximized(true);
   			mainStage.setScene(easygame);
   			mainStage.show();
   			
         
            
   }else if(Hard.isSelected()){
	   try {
           battle = new Battle(1, 0, 100, 5, 250);
       } catch (IOException e) {
           System.out.println("Error, please  try again"+e.getMessage());
    	   e.printStackTrace();
       }
       ps = new AnchorPane();
       ps.setStyle("-fx-background-color: red;");
       hardgame = new Scene(ps, 1500, 1000);
       Lane1=new VBox();
		 Lane1.setLayoutX(7);
		 Lane1.setLayoutY(7);
		 Lane1.setPrefWidth(260);
		 Lane1.setPrefHeight(200);
		 ps.getChildren().add(Lane1);
		 Lane2=new VBox();
		 Lane2.setLayoutX(281);
		 Lane2.setLayoutY(7);
		 Lane2.setPrefWidth(260);
		 Lane2.setPrefHeight(200);
		 ps.getChildren().add(Lane2);
		 Lane3=new VBox();
		 Lane3.setLayoutX(556);
		 Lane3.setLayoutY(7);
		 Lane3.setPrefWidth(260);
		 Lane3.setPrefHeight(200);
		 ps.getChildren().add(Lane3);
		 Lane4=new VBox();
		 Lane4.setLayoutX(833);
		 Lane4.setLayoutY(7);
		 Lane4.setPrefWidth(260);
		 Lane4.setPrefHeight(200);
		 ps.getChildren().add(Lane4);
		 Lane5=new VBox();
		 Lane5.setLayoutX(1115);
		 Lane5.setLayoutY(7);
		 Lane5.setPrefWidth(260);
		 Lane5.setPrefHeight(200);
		 ps.getChildren().add(Lane5);
		 we = new Label("Weapon");
		 we.setLayoutX(23);
		 we.setLayoutY(864);
		 we.setPrefWidth(95);
		 we.setPrefHeight(41);
		 ps.getChildren().add(we);
		 W1 = new RadioButton("Anti-Titan Shell");
		 W1.setLayoutX(112);
		 W1.setLayoutY(815);
		 W1.setPrefWidth(170);
		 W1.setPrefHeight(25);
		 ps.getChildren().add(W1);
		 W2 = new RadioButton("Long RangeSpear");
		 W2.setLayoutX(112);
		 W2.setLayoutY(847);
		 W2.setPrefWidth(170);
		 W2.setPrefHeight(25);
		 ps.getChildren().add(W2);
		 W3 = new RadioButton("Wall SpreadCannon");
		 W3.setLayoutX(112);
		 W3.setLayoutY(874);
		 W3.setPrefWidth(170);
		 W3.setPrefHeight(25);
		 ps.getChildren().add(W3);
		 W4 = new RadioButton("Proximity Trap");
		 W4.setLayoutX(112);
		 W4.setLayoutY(900);
		 W4.setPrefWidth(170);
		 W4.setPrefHeight(25);
		 ps.getChildren().add(W4);
		 s1=new Pane();
		 s1.setLayoutX(7);
		 s1.setLayoutY(207);
		 s1.setPrefWidth(200);
		 s1.setPrefHeight(500);
		 s1.setStyle("-fx-background-color: white;");
		 ps.getChildren().add(s1);
		 s2=new Pane();
		 s2.setLayoutX(281);
		 s2.setLayoutY(207);
		 s2.setPrefWidth(200);
		 s2.setPrefHeight(500);
		 s2.setStyle("-fx-background-color: white;");
		 ps.getChildren().add(s2);
		 s3=new Pane();
		 s3.setLayoutX(556);
		 s3.setLayoutY(207);
		 s3.setPrefWidth(200);
		 s3.setPrefHeight(500);
		 s3.setStyle("-fx-background-color: white;");
		 ps.getChildren().add(s3);
		 s4=new Pane();
		 s4.setLayoutX(833);
		 s4.setLayoutY(207);
		 s4.setPrefWidth(200);
		 s4.setPrefHeight(500);
		 s4.setStyle("-fx-background-color: white;");
		 ps.getChildren().add(s4);
		 s5=new Pane();
		 s5.setLayoutX(1115);
		 s5.setLayoutY(207);
		 s5.setPrefWidth(200);
		 s5.setPrefHeight(500);
		 s5.setStyle("-fx-background-color: white;");
		 ps.getChildren().add(s5);
		 Purchase = new Button("purchase");
		 Purchase.setLayoutX(381);
		 Purchase.setLayoutY(854);
		 Purchase.setPrefWidth(88);
		 Purchase.setPrefHeight(26);
		 Purchase.setOnMouseClicked( ae -> {purchasehard();});
		 ps.getChildren().add(Purchase);
		 
		 
		 l1 = new Label();
		 l1.setLayoutX(0);
		 l1.setLayoutY(0);
		 l1.setPrefWidth(260);
		 l1.setPrefHeight(27);
		 l1.setStyle("-fx-background-image: url('wall3.jpg');");
		 l1.setTextFill(Color.WHITE);
		 Lane1.getChildren().add(l1);
		 l2 = new Label();
		 l2.setLayoutX(0);
		 l2.setLayoutY(0);
		 l2.setPrefWidth(260);
		 l2.setPrefHeight(27);
		 l2.setStyle("-fx-background-image: url('wall3.jpg');");
		 l2.setTextFill(Color.WHITE);
		 Lane2.getChildren().add(l2);
		 l3 = new Label();
		 l3.setLayoutX(0);
		 l3.setLayoutY(0);
		 l3.setPrefWidth(260);
		 l3.setPrefHeight(27);
		 l3.setStyle("-fx-background-image: url('wall3.jpg');");
		 l3.setTextFill(Color.WHITE);
		 Lane3.getChildren().add(l3);
		 l4 = new Label();
		 l4.setLayoutX(0);
		 l4.setLayoutY(0);
		 l4.setPrefWidth(260);
		 l4.setPrefHeight(27);
		 l4.setStyle("-fx-background-image: url('wall3.jpg');");
	 l4.setTextFill(Color.WHITE);
		 Lane4.getChildren().add(l4);
		 l5 = new Label();
		 l5.setLayoutX(0);
		 l5.setLayoutY(0);
		 l5.setPrefWidth(260);
		 l5.setPrefHeight(27);
		 l5.setStyle("-fx-background-image: url('wall3.jpg');");
		 l5.setTextFill(Color.WHITE);
		 Lane5.getChildren().add(l5);
		 Wall1whole = new VBox();
			 for(int i=0;i<4;i++) {
				 HBox wallll= new HBox(); 
				wallll.setLayoutX(0);
				wallll.setLayoutY(0+32*i);
				wallll.setPrefWidth(200);
				wallll.setPrefHeight(30);
				Wall1whole.getChildren().add(wallll);
			 }
			 Wall1 = new HBox();
			 Wall1.setLayoutX(0);
			 Wall1.setLayoutY(0);
			 Wall1.setPrefWidth(200);
			 Wall1.setPrefHeight(150);
			 Lane1.getChildren().add(Wall1whole);
			 Wall2whole = new VBox();
			 for(int i=0;i<4;i++) {
				 HBox wallll= new HBox(); 
				wallll.setLayoutX(0);
				wallll.setLayoutY(0+32*i);
				wallll.setPrefWidth(200);
				wallll.setPrefHeight(30);
				Wall2whole.getChildren().add(wallll);
			 }
			 Wall2 = new HBox();
			 Wall2.setLayoutX(0);
			 Wall2.setLayoutY(0);
			 Wall2.setPrefWidth(200);
			 Wall2.setPrefHeight(150);
			 Lane2.getChildren().add(Wall2whole);
			Wall3whole = new VBox();
			 for(int i=0;i<4;i++) {
				 HBox wallll= new HBox(); 
				wallll.setLayoutX(0);
				wallll.setLayoutY(0+32*i);
				wallll.setPrefWidth(200);
				wallll.setPrefHeight(30);
				Wall3whole.getChildren().add(wallll);
			 }
			 Wall3 = new HBox();
			 Wall3.setLayoutX(0);
			 Wall3.setLayoutY(0);
			 Wall3.setPrefWidth(200);
			 Wall3.setPrefHeight(150);
			 Lane3.getChildren().add( Wall3whole);
			 Wall4whole = new VBox();
			 for(int i=0;i<4;i++) {
				 HBox wallll= new HBox(); 
				wallll.setLayoutX(0);
				wallll.setLayoutY(0+32*i);
				wallll.setPrefWidth(200);
				wallll.setPrefHeight(30);
				Wall4whole.getChildren().add(wallll);
			 }
		 Wall4 = new HBox();
		 Wall4.setLayoutX(0);
		 Wall4.setLayoutY(0);
		 Wall4.setPrefWidth(200);
		 Wall4.setPrefHeight(150);
		 Lane4.getChildren().add( Wall4whole);
		 Wall5whole = new VBox();
		 for(int i=0;i<4;i++) {
			 HBox wallll= new HBox(); 
			wallll.setLayoutX(0);
			wallll.setLayoutY(0+32*i);
			wallll.setPrefWidth(200);
			wallll.setPrefHeight(30);
			Wall5whole.getChildren().add(wallll);
		 }
		 Wall5 = new HBox();
		 Wall5.setLayoutX(0);
		 Wall5.setLayoutY(0);
		 Wall5.setPrefWidth(200);
		 Wall5.setPrefHeight(150);
		 
		 Lane5.getChildren().add( Wall5whole);
		 
		
		 Score = new Label();
		 Score.setLayoutX(476);
		 Score.setLayoutY(867);
		 Score.setPrefWidth(113);
		 Score.setPrefHeight(18);
		 ps.getChildren().add( Score);
		 Turn = new Label();
		 Turn.setLayoutX(476);
		 Turn.setLayoutY(896);
		 Turn.setPrefWidth(113);
		 Turn.setPrefHeight(18); 
		 ps.getChildren().add( Turn);
		 Phase = new Label();
		 Phase.setLayoutX(476);
		 Phase.setLayoutY(923);
		 Phase.setPrefWidth(125);
		 Phase.setPrefHeight(18);
		 ps.getChildren().add( Phase);
		 Resources = new Label();
		 Resources.setLayoutX(476);
		 Resources.setLayoutY(951);
		 Resources.setPrefWidth(113);
		 Resources.setPrefHeight(18);
		 ps.getChildren().add( Resources);
		 Label WeaponInfo = new Label("Weapon details"+"\n"+"Anti-TitanShell: type: PiercingCannon, price: 25, damage: 10"+"\n"+"Long Range Spear: type: Sniper Cannon ,price: 25, damage: 35 "+"\n"+"Wall Spread Cannon: type: Volley Spread Cannon, price: 100, damage: 5 "+"\n"+"Proximity Trap: type: Wall Trap, price: 75, damage: 100"+"\n");
		 WeaponInfo.setLayoutX(715);
		 WeaponInfo.setLayoutY(830);
		 WeaponInfo.setPrefWidth(700);
		 WeaponInfo.setPrefHeight(188);
		 ps.getChildren().add(WeaponInfo);
		 Score.setText("score:"+battle.getScore());
		Turn.setText("Turn:"+battle.getNumberOfTurns());
		Phase.setText("Phase"+battle.getBattlePhase());
		Resources.setText("Resources"+battle.getResourcesGathered());
		l1.setText("danger:"+battle.getOriginalLanes().get(0).getDangerLevel()+"     Health"+battle.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
		l2.setText("danger:"+battle.getOriginalLanes().get(1).getDangerLevel()+"    Health"+battle.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
		l3.setText("danger:"+battle.getOriginalLanes().get(2).getDangerLevel()+"    Health"+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
		l4.setText("danger:"+battle.getOriginalLanes().get(3).getDangerLevel()+"     Health"+battle.getOriginalLanes().get(3).getLaneWall().getCurrentHealth());
		l5.setText("danger:"+battle.getOriginalLanes().get(4).getDangerLevel()+"    Health"+battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth());
	 laneComboBox = new ComboBox<>();
	 laneComboBox.getItems().addAll("Lane 1", "Lane 2", "Lane 3","Lane 4","Lane 5");
	 laneComboBox.setLayoutX(151);
	 laneComboBox.setLayoutY(956);
	 laneComboBox.setPrefWidth(170);
	 laneComboBox.setPrefHeight(25);
	 ps.getChildren().add(laneComboBox);
	 laneno=new Label("Lane number");
	 laneno.setLayoutX(19);
	 laneno.setLayoutY(950);
	 laneno.setPrefWidth(111);
	 laneno.setPrefHeight(27);
	 ps.getChildren().add(laneno);
	 
		
		Pass = new Button("Pass Turn");
		 Pass.setLayoutX(373);
		 Pass.setLayoutY(863);
		 Pass.setPrefWidth(88);
		 Pass.setPrefHeight(26);
		Pass.setOnMouseClicked( ae -> { 
	battle.passTurn();updateUIH();});
		ps.getChildren().add(Pass);
		ai= new Button("Ai play");
		ai.setLayoutX(573);
		 ai.setLayoutY(863);
		 ai.setPrefWidth(88);
		 ai.setPrefHeight(26);
		 ai.setOnMouseClicked(e->{
             try {
                 calculateBestMove(3);
             } catch (IOException ex) {
                 throw new RuntimeException(ex);
             }
             updateUIH();
		 });
         ps.getChildren().add(ai);
		mainStage.setMaximized(true);
		mainStage.setScene(hardgame);
        mainStage.show();
   
   }
   }else if (event.getSource() == startmenu){
	   mainStage.setScene(startscene);
	   mainStage.show();
	   
   }
        
          
     
       
}
   public int best;
   public int danger;
    public String seq;
    public void calculateBestMove(int depth) throws IOException {
    	//write a backtracking algorithm that will check each possible situation for the next 5 moves and find the best one accross them
        	//for each move, calculate the score and choose the one with the highest score and the lowest sum of dangerlevel
        best=-1;
        seq="";
        backtracking(depth,"", battle.deepCopyofEveryThing());
        if(seq.charAt(0)=='0'){
            battle.passTurn();
        }else{
                purchasehard(seq.charAt(0)-'0',seq.charAt(1)-'0');
        }
    }

    public void backtracking(int depth,String seq,Battle b) throws IOException {
        if(depth==0){
            if(best==-1) {
                best = b.getScore();
                this.seq = seq;
                danger=b.dangerSum();
            }else if(b.getScore()>best) {
                best = b.getScore();
                this.seq = seq;
                danger=b.dangerSum();
            }else if(b.getScore()==best) {
            	if(b.dangerSum()<danger) {
            		best = b.getScore();
                    this.seq = seq;
                    danger=b.dangerSum();
            	}
            }
            return;
        }
        int perm[]=new int[] {1,2,3,4};
        for(int i=0;i<perm.length;i++) {
        	int index=(int)(Math.random()*(i+1));
        	int temp = perm[i];
        	perm[i]=perm[index];
        	perm[index]=temp;
        }
        int[] permlanes=new int[b.getOriginalLanes().size()];
        for(int i=0;i<b.getOriginalLanes().size();i++) {
        	permlanes[i]=i;
        }
        for(int i=0;i<permlanes.length;i++) {
        	int index=(int)(Math.random()*(i+1));
        	int temp = permlanes[i];
        	permlanes[i]=permlanes[index];
        	permlanes[index]=temp;
        }
        for(int j=1;j<=4;j++) {
        	int i=perm[j-1];
            for(int k=0;k<b.getOriginalLanes().size();k++) {
            	int lane=permlanes[k];
                if(b.getOriginalLanes().get(lane).isLaneLost())
                    continue;
                if(b.getResourcesGathered()<b.getWeaponPrice(i))
                    continue;
                Battle b1 = b.deepCopyofEveryThing();
                try {
                    b1.purchaseWeapon(i, b1.getOriginalLanes().get(lane));
                } catch (InsufficientResourcesException e) {
                    e.printStackTrace();
                } catch (InvalidLaneException e) {
                    e.printStackTrace();
                }
                backtracking(depth-1,seq+i+lane,b1);
            }
        }
        backtracking(depth-1,seq+0+0,b.deepCopyofEveryThing());
    }
    
        
    

    public static void main(String[] args) {
        launch(args);
    }
}



